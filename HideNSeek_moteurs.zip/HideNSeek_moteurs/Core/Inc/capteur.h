/*
 * capteur.h
 *
 *  Created on: Jun 10, 2023
 *      Author: sargsyan
 */

void IR(void);
int ultrason(void);
