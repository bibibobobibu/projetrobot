/*
 * modes_fonctionnement.h
 *
 *  Created on: Jun 1, 2023
 *      Author: matth
 */

#ifndef INC_MODES_FONCTIONNEMENT_H_
#define INC_MODES_FONCTIONNEMENT_H_

void marche_avant_ralenti(void);
void tourner_a_gauche(void);
void tourner_a_droite(void);
void marche_arriere(void);
void robot_walk(int);
void marche_avant(void);

#endif /* INC_MODES_FONCTIONNEMENT_H_ */
