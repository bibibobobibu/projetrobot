/*
 * capteur.c
 *
 *  Created on: Jun 10, 2023
 *      Author: sargsyan
 *
 *
 */
#include "main.h"
#include <stdio.h>
#include "stm32h7xx_hal.h"
//TIM_HandleTypeDef htim3;


#define IR_SENSOR_PORT GPIOE
#define IR_SENSOR_PIN GPIO_PIN_14

#define IR_LED_PORT GPIOE
#define IR_LED_PIN GPIO_PIN_13

#define TRIGGER_PORT GPIOE
#define TRIGGER_PIN GPIO_PIN_14

#define ECHO_PORT GPIOE
#define ECHO_PIN GPIO_PIN_13

void IR (void){
   // Lecture de la valeur du capteur infrarouge
              GPIO_PinState sensorValue = HAL_GPIO_ReadPin(IR_SENSOR_PORT, IR_SENSOR_PIN);
              GPIO_PinState sensorValueLED = HAL_GPIO_ReadPin(IR_LED_PORT, IR_LED_PIN);
              HAL_GPIO_WritePin(IR_LED_PORT, IR_LED_PIN, GPIO_PIN_SET);
              // Allumer ou éteindre la LED émetteur infrarouge en fonction de la valeur du capteur
              if (sensorValue == GPIO_PIN_SET) {
                HAL_GPIO_WritePin(IR_LED_PORT, IR_LED_PIN, GPIO_PIN_SET);  // Allumer la LED
              } else {
                HAL_GPIO_WritePin(IR_LED_PORT, IR_LED_PIN, GPIO_PIN_RESET);  // Éteindre la LED
              }
              GPIO_PinState sensorValueLED2 = HAL_GPIO_ReadPin(IR_LED_PORT, IR_LED_PIN);

              HAL_Delay(100);  // Délai entre chaque lecture du capteur
              HAL_GPIO_WritePin(IR_LED_PORT, IR_LED_PIN, GPIO_PIN_RESET);

              HAL_GPIO_WritePin(IR_SENSOR_PORT, IR_SENSOR_PIN, GPIO_PIN_RESET);
              HAL_Delay(100);  // Délai entre chaque lecture du capteur
              GPIO_PinState sensorValue2 = HAL_GPIO_ReadPin(IR_SENSOR_PORT, IR_SENSOR_PIN);
              HAL_GPIO_WritePin(IR_SENSOR_PORT, IR_SENSOR_PIN, GPIO_PIN_RESET);
}

int ultrason(void){

	    HAL_GPIO_WritePin(TRIGGER_PORT, TRIGGER_PIN, GPIO_PIN_SET);
	    HAL_Delay(10);
	    HAL_GPIO_WritePin(TRIGGER_PORT, TRIGGER_PIN, GPIO_PIN_RESET);

	    // Attendre la réponse de l'écho
	    while (HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN) == GPIO_PIN_RESET);

	    // Démarrer le timer
	  //  HAL_TIM_Base_Start(&htim3);
	  //  __HAL_TIM_SetCounter(&htim3, 0);


	    while (HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN) == GPIO_PIN_SET);

	    // Arrêter le timer et calculer la distance
	  //  int pulseDuration = __HAL_TIM_GetCounter(&htim3);
	   // float distance = pulseDuration * 0.0343 / 2;  //  343 m/s


}

