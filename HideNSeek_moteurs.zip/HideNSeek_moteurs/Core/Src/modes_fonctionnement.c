/*
 * modes_fonctionnement.c
 *
 *  Created on: Jun 1, 2023
 *      Author: matth
 */
#include <stm32h7xx.h>
#include "modes_fonctionnement.h"

void marche_avant(void){

	TIM2-> PSC = 0x31f;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1,GPIO_PIN_SET);
  }


void marche_avant_ralenti(void){

	TIM2-> PSC = 0x63f;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1,GPIO_PIN_SET);
  }


void tourner_a_gauche(void){

	TIM2-> PSC = 0x63f;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1,GPIO_PIN_SET);
  }


void tourner_a_droite(void){

	TIM2-> PSC = 0x63f;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1,GPIO_PIN_RESET);
  }


void marche_arriere(void){
	TIM2-> PSC = 0x63f;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1,GPIO_PIN_RESET);
}

void robot_walk(int nbre_appui_bouton){

	switch (nbre_appui_bouton)
	{
	  case 1:
		marche_avant_ralenti();
	    break;

	  case  2:
	    tourner_a_gauche();
	    break;

	  case  3:
	    tourner_a_droite();
	  	break;

	  case  4:
	  	marche_arriere();
	  	break;

	  default:
		marche_avant();
	    break;
	}
}
